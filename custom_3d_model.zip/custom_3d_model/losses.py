import torch
from torch import nn
import torch.nn.functional as F
import pytorch_lightning as pl
from model import DETR3D
from matcher import HungarianMatcher3D


def euler_to_matrix(euler):
    """Z-Y-X intrinsic; euler shape (..., 3)."""
    rx, ry, rz = euler.unbind(-1)
    cx, sx = torch.cos(rx), torch.sin(rx)
    cy, sy = torch.cos(ry), torch.sin(ry)
    cz, sz = torch.cos(rz), torch.sin(rz)

    Rz = torch.stack([
        torch.stack([cz, -sz, torch.zeros_like(cz)], -1),
        torch.stack([sz,  cz, torch.zeros_like(cz)], -1),
        torch.stack([torch.zeros_like(cz), torch.zeros_like(cz), torch.ones_like(cz)], -1),
    ], -2)
    Ry = torch.stack([
        torch.stack([cy, torch.zeros_like(cy), sy], -1),
        torch.stack([torch.zeros_like(cy), torch.ones_like(cy), torch.zeros_like(cy)], -1),
        torch.stack([-sy, torch.zeros_like(cy), cy], -1),
    ], -2)
    Rx = torch.stack([
        torch.stack([torch.ones_like(cx), torch.zeros_like(cx), torch.zeros_like(cx)], -1),
        torch.stack([torch.zeros_like(cx), cx, -sx], -1),
        torch.stack([torch.zeros_like(cx), sx,  cx], -1),
    ], -2)
    return Rz @ Ry @ Rx


def build_corners(center, size, rot_euler):
    """center (...,3), size (...,3) w,h,d, rot (...,3) -> (...,8,3)"""
    w, h, d = size.unbind(-1)
    # 8 unit corners in object frame
    sx = torch.stack([-w, -w, -w, -w,  w,  w,  w,  w], -1) / 2
    sy = torch.stack([ h,  h, -h, -h,  h,  h, -h, -h], -1) / 2
    sz = torch.stack([-d,  d,  d, -d, -d,  d,  d, -d], -1) / 2
    corners = torch.stack([sx, sy, sz], -1)  # (...,8,3)

    R = euler_to_matrix(rot_euler)           # (...,3,3)
    corners = torch.einsum('...ij,...kj->...ki', R, corners)
    return corners + center.unsqueeze(-2)


class Parcel3DLitModule(pl.LightningModule):
    def __init__(self, num_queries=10, lr=1e-4, weight_decay=1e-4):
        super().__init__()
        self.save_hyperparameters()
        self.model = DETR3D(num_queries=num_queries)
        self.matcher = HungarianMatcher3D()
        self.class_weight = torch.tensor([0.1, 1.0])

    def forward(self, x):
        return self.model(x)

    def compute_loss(self, outputs, targets):
        indices = self.matcher(outputs, targets)

        # --- Classification loss ---
        pred_logits = outputs["pred_logits"]   # (B, Q, 2)
        B, Q, _ = pred_logits.shape

        target_classes = torch.zeros(B, Q, dtype=torch.long, device=pred_logits.device)
        for b, (qi, ti) in enumerate(indices):
            target_classes[b, qi] = 1

        loss_ce = F.cross_entropy(
            pred_logits.reshape(-1, 2),
            target_classes.reshape(-1),
            weight=self.class_weight.to(pred_logits.device),
        )

        # --- Regression losses on matched queries ---
        loss_center = pred_logits.new_zeros(())
        loss_size = pred_logits.new_zeros(())
        loss_rot = pred_logits.new_zeros(())
        loss_corner = pred_logits.new_zeros(())
        n_total = 0

        for b, (qi, ti) in enumerate(indices):
            if qi.numel() == 0:
                continue
            pc = outputs["pred_centers"][b, qi]
            ps = outputs["pred_sizes"][b, qi]
            pr = outputs["pred_rot"][b, qi]

            tc = targets[b]["centers"][ti]
            ts = targets[b]["sizes"][ti]
            tr = targets[b]["rotations"][ti]
            tcorners = targets[b]["boxes_3d"][ti]  # (n,8,3)

            loss_center = loss_center + F.l1_loss(pc, tc, reduction="sum")
            loss_size = loss_size + F.l1_loss(ps, ts, reduction="sum")
            # rotation as sin/cos to avoid wrap-around
            loss_rot = loss_rot + F.l1_loss(torch.sin(pr), torch.sin(tr), reduction="sum") + \
                                  F.l1_loss(torch.cos(pr), torch.cos(tr), reduction="sum")

            pred_corners = build_corners(pc, ps, pr)  # (n,8,3)
            loss_corner = loss_corner + F.l1_loss(pred_corners, tcorners, reduction="sum")
            n_total += qi.numel()

        n_total = max(n_total, 1)
        loss_center = loss_center / n_total
        loss_size = loss_size / n_total
        loss_rot = loss_rot / n_total
        loss_corner = loss_corner / (n_total * 8)

        loss = (2.0 * loss_ce +
                5.0 * loss_center +
                2.0 * loss_size +
                1.0 * loss_rot +
                5.0 * loss_corner)

        return loss, {
            "loss": loss.detach(),
            "ce": loss_ce.detach(),
            "center": loss_center.detach(),
            "size": loss_size.detach(),
            "rot": loss_rot.detach(),
            "corner": loss_corner.detach(),
        }

    def training_step(self, batch, batch_idx):
        imgs, targets = batch
        out = self.model(imgs)
        loss, logs = self.compute_loss(out, targets)
        for k, v in logs.items():
            self.log(f"train/{k}", v, prog_bar=(k == "loss"), batch_size=imgs.size(0))
        return loss

    def validation_step(self, batch, batch_idx):
        imgs, targets = batch
        out = self.model(imgs)
        loss, logs = self.compute_loss(out, targets)
        for k, v in logs.items():
            self.log(f"val/{k}", v, prog_bar=(k == "loss"), batch_size=imgs.size(0))
        return loss

    def configure_optimizers(self):
        backbone_params = list(self.model.backbone.parameters())
        backbone_ids = {id(p) for p in backbone_params}
        other_params = [p for p in self.model.parameters() if id(p) not in backbone_ids]

        optim = torch.optim.AdamW([
            {"params": backbone_params, "lr": self.hparams.lr * 0.1},
            {"params": other_params, "lr": self.hparams.lr},
        ], weight_decay=self.hparams.weight_decay)

        sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=100)
        return {"optimizer": optim, "lr_scheduler": sched}